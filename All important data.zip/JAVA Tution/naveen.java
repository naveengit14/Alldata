class naveen
{  

int count=0;//will get memory when instance is created  
  
naveen()
{  
count++;  
System.out.println(count);  
}  
  
public static void main(String args[])
{  
  
naveen c1=new naveen();  
naveen c2=new naveen();  
naveen c3=new naveen();  
  
 }
  
}  